/*
SQLyog 企业版 - MySQL GUI v8.14 
MySQL - 5.1.50-community : Database - dormitory
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`dormitory` /*!40100 DEFAULT CHARACTER SET gbk */;

USE `dormitory`;

/*Table structure for table `d_user` */

DROP TABLE IF EXISTS `d_user`;

CREATE TABLE `d_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userName` varchar(20) DEFAULT NULL,
  `userPassword` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=gbk;

/*Data for the table `d_user` */

insert  into `d_user`(`id`,`userName`,`userPassword`) values (1,'s1','123');

/*Table structure for table `room_message` */

DROP TABLE IF EXISTS `room_message`;

CREATE TABLE `room_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member` varchar(20) DEFAULT NULL,
  `leader` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=gbk;

/*Data for the table `room_message` */

insert  into `room_message`(`id`,`member`,`leader`) values (2,'25109','舒剑'),(4,'25106','pz'),(5,'25108','刘宇'),(6,'251010','ASD');

/*Table structure for table `student_message` */

DROP TABLE IF EXISTS `student_message`;

CREATE TABLE `student_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `sex` varchar(10) DEFAULT NULL,
  `yuanxi` varchar(20) DEFAULT NULL,
  `classroom` varchar(20) DEFAULT NULL,
  `dormitory` int(11) DEFAULT NULL,
  `bed` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_student_message` (`dormitory`),
  CONSTRAINT `FK_student_message` FOREIGN KEY (`dormitory`) REFERENCES `room_message` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=gbk;

/*Data for the table `student_message` */

insert  into `student_message`(`id`,`name`,`sex`,`yuanxi`,`classroom`,`dormitory`,`bed`) values (6,'李华阳','男','信工','1',5,2),(9,'刘宇','男','信工','1',5,4),(10,'戴康','男','信工','1',5,1),(11,'刁雨健','男','信工','1',5,3);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
